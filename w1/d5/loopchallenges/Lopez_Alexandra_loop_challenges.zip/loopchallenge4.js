var sum=0;
var i=1;

for(i=1;i<=100;i++){
    sum = sum + i;
}

console.log(sum);