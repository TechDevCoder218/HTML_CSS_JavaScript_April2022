var newArr = [4,2.5,1,-0.5,-2,-3.5];
var i=0;

for(i=0;i<newArr.length;i++){
    console.log(newArr[i]);
}